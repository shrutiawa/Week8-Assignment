import { StyleSheet, Text, View } from 'react-native';
import Home from './components/screens/home';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HeroesComp from './components/screens/heroes';
// Stack 
//Tab 
//Drawer

let Stack=createNativeStackNavigator();
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={Home}/>
        <Stack.Screen name="Heroes" component={HeroesComp}/>
        {/* <Stack.Screen name="Batman" component={BatmanComp}/>
        <Stack.Screen name="Superman" component={SupermanComp}/>
        <Stack.Screen name="WonderWoman" component={WonderwomanComp}/> */}
      </Stack.Navigator>

    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
