import { SafeAreaView } from "react-native-safe-area-context"
import { View ,Text,Image, Button, TextInput} from "react-native"

let HeroesComp=(props)=>{

    return <SafeAreaView>
        {/* <View style={styles.container}>
        {data.herolist.map((val,idx)=>
            <Button onPress={()=>props.navigation.navigate(val.title,{poster,title})} title={val.title}/>
            )}
            <Button onPress={()=>props.navigation.navigate("Home")} title="Home"/>
        </View> */}
         <Text>{props.route.params?.title}</Text>
         <Text>{props.route.params?.firstname}</Text>
         <Text>{props.route.params?.lastname}</Text>
         <Image style={{width:200,height:200,borderColor:"red"}} source={{ uri: props.route.params.poster }}/>
         {console.log(props.route.params.poster)}
    </SafeAreaView>
}
export default  HeroesComp