import { SafeAreaView } from "react-native-safe-area-context"
import { styles } from "./style"
import { View ,Text, Button} from "react-native"
import data from "../../assets/data/data.json"


let Home=(props)=>{
    return <SafeAreaView>
        <View style={styles.container}>
        {data.herolist.map((val,idx)=>
            <Button onPress={()=>props.navigation.navigate("Heroes",{poster:val.poster,title:val.title,firstname:val.firstname,lastname:val.lastname})} title={val.title}/>
            )}
        </View>
    </SafeAreaView>
}
export default  Home